package com.kis.tolamaornegi;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {
    TextView tvSonuc;
    EditText etSay1, etSay2;
    Button btnCikar;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        tvSonuc = findViewById(R.id.tvSonuc);
        etSay1 = findViewById(R.id.etSay1);
        etSay2 = findViewById(R.id.etSay2);
        btnCikar = findViewById(R.id.btnCikar);

        btnCikar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                int s1 = Integer.parseInt(etSay1.getText().toString());
                int s2 = Integer.parseInt(etSay2.getText().toString());

                int sonuc = s1 - s2;
                btnCikar.setText("Cıkarıldı");

                tvSonuc.setText(s1+" - "+s2+" = "+sonuc);

            }
        });

    }

    public void toplama(View view) {
        int s1 = Integer.parseInt(etSay1.getText().toString());
        int s2 = Integer.parseInt(etSay2.getText().toString());

        int sonuc = s1 + s2;

        tvSonuc.setText(s1+" + "+s2+" = "+sonuc);

    }
}
