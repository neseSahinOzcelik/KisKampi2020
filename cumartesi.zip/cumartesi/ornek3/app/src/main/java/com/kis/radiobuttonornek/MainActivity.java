package com.kis.radiobuttonornek;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {
    RadioButton rbCash, rbVisa;
    RadioGroup radioGroupOdeme;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        rbCash = findViewById(R.id.rbCash);
        rbVisa = findViewById(R.id.rbVisa);
        radioGroupOdeme = findViewById(R.id.rgOdeme);

        rbVisa.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Toast.makeText(MainActivity.this, "radio button visa secili", Toast.LENGTH_LONG).show();
             }
        });
    }

    public void onClick(View view) {
        //RadioButton rb = (RadioButton)view;
        Toast.makeText(this, "radio button Cash secili", Toast.LENGTH_LONG).show();
    }

    public void odeme(View view) {
        int rbSeciliolaninIdsi = radioGroupOdeme.getCheckedRadioButtonId();
        switch (rbSeciliolaninIdsi){
            case R.id.rbVisa:
                Toast.makeText(this, "Visa hesaplam", Toast.LENGTH_LONG).show();
                break;
            case R.id.rbCash:
                Toast.makeText(this, "cash hesaplam", Toast.LENGTH_LONG).show();
                break;
        }
    }
}
