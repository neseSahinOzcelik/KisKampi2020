package com.kis2020;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }
    public void ekranaBas(View v){
        Toast.makeText(this,"Merhaba", Toast.LENGTH_LONG).show();
    }
    public void sil(View view) {
        switch (view.getId()) {
            case  R.id.btnIptal:
                Toast t = Toast.makeText(this, "Sil tıklandı", Toast.LENGTH_LONG);
                t.setGravity(Gravity.CENTER_HORIZONTAL, 0, 0);
                t.show();
                Button btnIptal = (Button)view;
                btnIptal.setText("Silindi");
                break;
            case R.id.btnHesapla:
                Toast.makeText(this, "Hesapla tıklandı", Toast.LENGTH_LONG).show();
                break;
        }

    }
}
