package com.kis.checkboxornek;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.CheckBox;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {
    CheckBox cb1, cb2;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        cb1 = findViewById(R.id.cb1);
        cb2 = findViewById(R.id.cb2);
        cb2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                /*
                CheckBox cbtmp = (CheckBox) v;
                if(cbtmp.isChecked()){

                }
                */

                if(cb2.isChecked())
                    display("Checkbox 2 secilidi");
                else
                    display("Checkbox 2 secilmedi");
            }
        });


    }

    public void onClick(View view) {
        if(view.getId() == R.id.cb1) {
            if(cb1.isChecked())
                display("Checkbox 1 secilidi");
            else
                display("Checkbox 1 secilmedi");

        }
    }
    public void display(String msg){
        Toast.makeText(this, msg, Toast.LENGTH_LONG).show();
    }
}
