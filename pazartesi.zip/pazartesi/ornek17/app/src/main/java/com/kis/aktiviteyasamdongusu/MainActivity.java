package com.kis.aktiviteyasamdongusu;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.util.Log;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        Log.d("ACTIVITYDONGUSU", "onCreate");
    }

    @Override
    protected void onRestart() {
        super.onRestart();

        Log.d("ACTIVITYDONGUSU", "onRestart");
    }

    @Override
    protected void onResume() {
        super.onResume();
        Log.d("ACTIVITYDONGUSU", "onResume");

    }

    @Override
    protected void onStart() {
        super.onStart();

        Log.d("ACTIVITYDONGUSU", "onStart");

    }

    @Override
    protected void onStop() {
        super.onStop();
        Log.d("ACTIVITYDONGUSU", "onStop");
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        Log.d("ACTIVITYDONGUSU", "onDestroy");
    }

}
