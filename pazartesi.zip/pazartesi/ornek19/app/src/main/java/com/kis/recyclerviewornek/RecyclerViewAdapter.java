package com.kis.recyclerviewornek;

import androidx.recyclerview.widget.RecyclerView;

public class RecyclerViewAdapter extends RecyclerView.Adapter<RecyclerViewAdapter.SosyalMedyaAlani> {

    class SosyalMedyaAlani{


    }
}
