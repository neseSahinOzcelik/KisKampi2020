package com.kis.customspinnerornek;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.Spinner;

import java.util.ArrayList;
import java.util.Collections;

public class MainActivity extends AppCompatActivity {

    //ArrayList<String> s = new ArrayList<>();
    ArrayList<SocialMedia> sosyalListe;
    Spinner spinnerSosyal;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        sosyalMedayaOlustur();

        spinnerSosyal = findViewById(R.id.spinnerSocial);

        /*
        s.add("Facebook");
        s.add("dfsdf");
        s.add("gmail");

        ArrayAdapter adapter = new ArrayAdapter(this, android.R.layout.simple_list_item_1, s);

        spinnerSosyal.setAdapter(adapter);
        */

        SpinnerAdapter spadapter = new SpinnerAdapter(this, R.layout.spinner_sosyal, sosyalListe);
        spinnerSosyal.setAdapter(spadapter);

    }

    public void sosyalMedayaOlustur(){
        sosyalListe = new ArrayList<>();

        Collections.addAll(sosyalListe,
                           new SocialMedia("Facebook",R.drawable.facebook),
                           new SocialMedia("Twitter", R.drawable.twitter),
                            new SocialMedia("Gmail",R.drawable.gmail)
                          );
    }
}
