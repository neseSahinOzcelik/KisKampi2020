package com.kis.customspinnerornek;

import android.content.Context;
import android.graphics.Color;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import java.util.ArrayList;
import java.util.List;

public class SpinnerAdapter extends ArrayAdapter<SocialMedia> {
    Context context;
    ArrayList<SocialMedia>sosyalmedyalar;
    public SpinnerAdapter(Context context, int resource, ArrayList<SocialMedia> sosyalmedyalar) {
        super(context, resource, sosyalmedyalar);

        this.context = context;
        this.sosyalmedyalar = sosyalmedyalar;

    }

    @NonNull
    @Override
    public View getView(int position, View convertView, ViewGroup parent) {

        LayoutInflater inflator = (LayoutInflater)context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
        View view = inflator.inflate(R.layout.spinner_sosyal, parent, false);

        TextView tvSosyal = view.findViewById(R.id.tvSosyal);
        ImageView imgSosyal = view.findViewById(R.id.imgSosyal);
        LinearLayout layoutSosyal = view.findViewById(R.id.layoutSosyal);

        SocialMedia sm = sosyalmedyalar.get(position);
        tvSosyal.setText(sm.getAd());
        imgSosyal.setImageResource(sm.getImgId());

        layoutSosyal.setBackgroundColor(Color.BLUE);

        return view;

    }

    @Override
    public View getDropDownView(int position, View convertView, ViewGroup parent) {

        LayoutInflater inflator = (LayoutInflater)context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
        View view = inflator.inflate(R.layout.spinner_sosyal, parent, false);

        TextView tvSosyal = view.findViewById(R.id.tvSosyal);
        ImageView imgSosyal = view.findViewById(R.id.imgSosyal);
        LinearLayout layoutSosyal = view.findViewById(R.id.layoutSosyal);

        SocialMedia sm = sosyalmedyalar.get(position);
        tvSosyal.setText(sm.getAd());
        imgSosyal.setImageResource(sm.getImgId());

        if(position % 2 == 0)
            layoutSosyal.setBackgroundColor(Color.YELLOW);
        else
            layoutSosyal.setBackgroundColor(Color.GREEN);

        return view;
    }
}
