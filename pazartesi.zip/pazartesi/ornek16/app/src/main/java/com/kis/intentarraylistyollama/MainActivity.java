package com.kis.intentarraylistyollama;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {
    ArrayList<Kitap> kitaplar;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        kitaplariOlustur();

    }

    public void onClick(View v){
        Intent intent = new Intent(this, IkinciAktivite.class);

        Bundle b = new Bundle();
        b.putParcelableArrayList("kipatlar",kitaplar);

        intent.putExtras(b);

        startActivity(intent);


    }
    public void kitaplariOlustur(){
        kitaplar = new ArrayList<>();

        Kitap k1 = new Kitap("java",30);
        Kitap k2 = new Kitap("Android",40);
        Kitap k3 = new Kitap("C++",25);

        kitaplar.add(k1);
        kitaplar.add(k2);
        kitaplar.add(k3);

    }
}
