package com.kis.intentarraylistyollama;

import android.os.Parcel;
import android.os.Parcelable;

public class Kitap implements Parcelable {
    private String name;
    private int fiyat;

    public Kitap(String name, int fiyat) {
        this.name = name;
        this.fiyat = fiyat;
    }
    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public int getFiyat() {
        return fiyat;
    }

    public void setFiyat(int fiyat) {
        this.fiyat = fiyat;
    }

    @Override
    public String toString() {
        return "Name: "+name +"Fiyat: "+fiyat+"\n";
    }

    protected Kitap(Parcel in) {
        name = in.readString();
        fiyat = in.readInt();
    }

    public static final Creator<Kitap> CREATOR = new Creator<Kitap>() {
        @Override
        public Kitap createFromParcel(Parcel in) {
            return new Kitap(in);
        }

        @Override
        public Kitap[] newArray(int size) {
            return new Kitap[size];
        }
    };
    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel dest, int flags) {
        dest.writeString(name);
        dest.writeInt(fiyat);
    }
}
