package com.kis.intentarraylistyollama;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.widget.TextView;

import java.util.ArrayList;

public class IkinciAktivite extends AppCompatActivity {
    Intent intentIkinci;
    TextView tvSonuc;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_ikinci_aktivite);

        tvSonuc = findViewById(R.id.tvSonuc);

        intentIkinci = getIntent();
        Bundle b = intentIkinci.getExtras();
        ArrayList<Kitap> kitaplar = b.getParcelableArrayList("kipatlar");

        String str="";
        for(int i = 0; i<kitaplar.size(); i++)
            str += kitaplar.get(i).toString();

        tvSonuc.setText(str);
    }


}
