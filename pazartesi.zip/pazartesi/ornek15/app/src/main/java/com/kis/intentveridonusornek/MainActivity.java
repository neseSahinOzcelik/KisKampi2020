package com.kis.intentveridonusornek;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    EditText etSay1,etSay2;
    int say1,say2;
    Intent intent;
    Bundle bundle;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }

    public void onClick(View view) {

        etSay1= findViewById(R.id.etSay1);
        etSay2= findViewById(R.id.etSay2);

        say1=Integer.parseInt(etSay1.getText().toString());
        say2=Integer.parseInt(etSay2.getText().toString());


        bundle = new Bundle();
        bundle.putInt("sayi1",say1);
        bundle.putInt("sayi2",say2);



        if (view.getId()==R.id.btnTopla)
        {
            intent = new Intent(this,IkinciAktivite.class);
            intent.putExtras(bundle);
            startActivityForResult(intent,1);
        }
        else
        {
            intent = new Intent(this,UcuncuAktivite.class);
            intent.putExtras(bundle);
            startActivityForResult(intent,2);
        }


    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if(requestCode==1)
        {
            if(resultCode==RESULT_OK)
            {
                Bundle bundleSonuc=data.getExtras();
                int sonuc=bundleSonuc.getInt("sonuc");

                Toast.makeText(this,"Toplama sonucu: "+sonuc,Toast.LENGTH_LONG).show();
            }
            else{
                Toast.makeText(this,"Hata alındı",Toast.LENGTH_LONG).show();

            }
        }
        else
        {
            if(resultCode==RESULT_OK)
            {
                Bundle bundleSonuc=data.getExtras();
                int sonuc=bundleSonuc.getInt("sonuc");

                Toast.makeText(this,"Çıkarma sonucu: "+sonuc,Toast.LENGTH_LONG).show();
            }
            else{
                Toast.makeText(this,"Hata alındı",Toast.LENGTH_LONG).show();

            }
        }
    }
}
