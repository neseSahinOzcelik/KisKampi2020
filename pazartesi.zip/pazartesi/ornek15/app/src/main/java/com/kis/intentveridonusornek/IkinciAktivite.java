package com.kis.intentveridonusornek;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;

public class IkinciAktivite extends AppCompatActivity {

    Intent intent,intentSonuc;
    Bundle bundle,bundleSonuc;
    int sonuc,say1,say2;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_ikinci_aktivite);

        intent = getIntent();
        bundle = intent.getExtras();

        say1 = bundle.getInt("sayi1");
        say2 = bundle.getInt("sayi2");

        sonuc = say1 + say2;


    }

    public void onClick(View view) {

        intentSonuc = new Intent();
        bundleSonuc = new Bundle();
        bundleSonuc.putInt("sonuc",sonuc);
        intentSonuc.putExtras(bundleSonuc);

        setResult(RESULT_OK,intentSonuc);

        finish();

    }
}
