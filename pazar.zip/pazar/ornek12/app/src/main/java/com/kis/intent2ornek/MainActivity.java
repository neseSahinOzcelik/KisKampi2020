package com.kis.intent2ornek;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;

public class MainActivity extends AppCompatActivity {

    EditText etSay1,etSay2;
    Intent intent;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        etSay1 = findViewById(R.id.etSay1);
        etSay2 = findViewById(R.id.etSay2);
    }
    public void onClick(View v){
        int say1;
        String say2;

        say1 = Integer.parseInt(etSay1.getText().toString());
        say2 = etSay2.getText().toString();

        intent = new Intent(this,ToplamaAktivitesi.class);

        intent.putExtra("sayi1",say1);
        intent.putExtra("sayi2",say2);

        startActivity(intent);

    }
}
