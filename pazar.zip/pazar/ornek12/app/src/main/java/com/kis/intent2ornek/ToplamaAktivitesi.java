package com.kis.intent2ornek;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.widget.TextView;

public class ToplamaAktivitesi extends AppCompatActivity {
    String say2;
    int say1;
    TextView tvSonuc;
    Intent intent;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_toplama_aktivitesi);

        tvSonuc = findViewById(R.id.tvSonuc);

        intent = getIntent();
        say1 = intent.getIntExtra("sayi1",0);
        say2 = intent.getStringExtra("sayi2");

        tvSonuc.setText((say1+Integer.parseInt(say2))+"");
    }
}
