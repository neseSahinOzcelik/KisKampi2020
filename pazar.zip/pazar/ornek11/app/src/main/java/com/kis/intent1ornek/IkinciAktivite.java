package com.kis.intent1ornek;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class IkinciAktivite extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_ikinci_aktivite);
    }
}
