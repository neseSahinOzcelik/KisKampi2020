package com.kis.spinnerornek;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {
    Spinner spinnerSehirler;
    String[] sehirlerArr = new String[]{"Ankara",  "Istanbul", "Izmir","Eskisehir"};

    boolean secildiDefault = true;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        spinnerSehirler = findViewById(R.id.spinnerSehirler);


        spinnerSehirler.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {

                if(secildiDefault)
                    secildiDefault = false;
                else {
                    TextView tv = (TextView) view;

                    String secilenSehir = tv.getText().toString();
                    secilenSehir = sehirlerArr[position];
                    secilenSehir = spinnerSehirler.getSelectedItem().toString();

                    Toast.makeText(MainActivity.this, secilenSehir + " secildi " + position, Toast.LENGTH_LONG).show();
                }
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });
    }
}
