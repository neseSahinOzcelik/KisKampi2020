package com.kis.intentbundleornek;

import android.content.Intent;
import android.os.Bundle;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

public class ToplamaAktivitesi extends AppCompatActivity {
    String say2;
    int say1;
    TextView tvSonuc;
    Intent intent;
    Bundle bundle;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_toplama_aktivitesi);

        tvSonuc = findViewById(R.id.tvSonuc);

        intent = getIntent();
        bundle = intent.getExtras();

        say1 = bundle.getInt("sayi1");
        say2 = bundle.getString("sayi2");

        tvSonuc.setText((say1+Integer.parseInt(say2))+"");
    }
}
