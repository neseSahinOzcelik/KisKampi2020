package com.kis.intentbundleornek;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;

import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    EditText etSay1,etSay2;
    Intent intent;
    Bundle bundle;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        etSay1 = findViewById(R.id.etSay1);
        etSay2 = findViewById(R.id.etSay2);
    }
    public void onClick(View v){
        int say1;
        String say2;

        say1 = Integer.parseInt(etSay1.getText().toString());
        say2 = etSay2.getText().toString();

        intent = new Intent(this,ToplamaAktivitesi.class);

        bundle = new Bundle();

        bundle.putInt("sayi1",say1);
        bundle.putString("sayi2",say2);

        intent.putExtras(bundle);

        startActivity(intent);

    }
}
