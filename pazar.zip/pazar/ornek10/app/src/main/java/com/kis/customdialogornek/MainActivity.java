package com.kis.customdialogornek;

import androidx.appcompat.app.AppCompatActivity;

import android.app.Dialog;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {
    Dialog cDialog;
    EditText etSay2;
    TextView tvSonuc;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        tvSonuc = findViewById(R.id.tvSonuc);
    }

    public void onClick(View view) {
        dialogGoster();

    }

    public void dialogGoster(){
        cDialog = new Dialog(this);
        cDialog.setContentView(R.layout.dialog);

        Button btnTopla = cDialog.findViewById(R.id.btnTopla);
        Button btnCikar = cDialog.findViewById(R.id.btnCikar);
        final EditText etSay1 = cDialog.findViewById(R.id.etSay1);
        etSay2 = cDialog.findViewById(R.id.etSay2);

        btnTopla.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                int s1 = Integer.parseInt(etSay1.getText().toString());
                int s2 = Integer.parseInt(etSay2.getText().toString());
                int sonuc = s1 + s2;
                tvSonuc.setText(sonuc+"");
                cDialog.dismiss();
            }
        });
        btnCikar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                int s1 = Integer.parseInt(etSay1.getText().toString());
                int s2 = Integer.parseInt(etSay2.getText().toString());
                int sonuc = s1 - s2;
                tvSonuc.setText(sonuc+"");
                cDialog.dismiss();
            }
        });

        cDialog.show();
    }
}
