package com.kis.alertdialogornek;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.content.DialogInterface;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {
    TextView tvSonuc;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        tvSonuc = findViewById(R.id.tvSonuc);
    }

    public void onClick(View view) {
        alertDialogGoster("Soru");

    }
    public void alertDialogGoster(String msg){
        AlertDialog.Builder aDialog = new AlertDialog.Builder(this);
        aDialog.setTitle("Title");
        aDialog.setMessage(msg);
        aDialog.setIcon(R.mipmap.ic_launcher);

        aDialog.setPositiveButton("Evet", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                tvSonuc.setText("Evet");
            }
        });

        aDialog.setNegativeButton("Hayır", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                tvSonuc.setText("Hayır");
            }
        });
        aDialog.setNeutralButton("Ertele", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                tvSonuc.setText("Ertele");
            }
        });
        aDialog.create();
        aDialog.show();

    }
}
