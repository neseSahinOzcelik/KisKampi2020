package com.nese.week12_jsonparsingexample;

public class Book {
    private String name;
    private String author;
    private int year;
    private String imgName;

    public Book(String name, String author, String year, String imgName) {
        this.name = name;
        this.author = author;
        this.year = Integer.parseInt(year);
        this.imgName = imgName;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getAuthor() {
        return author;
    }

    public void setAuthor(String author) {
        this.author = author;
    }

    public int getYear() {
        return year;
    }

    public void setYear(int year) {
        this.year = year;
    }

    public String getImgName() {
        return imgName;
    }

    public void setImgName(String imgName) {
        this.imgName = imgName;
    }
}
