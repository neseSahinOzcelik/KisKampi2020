package com.nese.week12_jsonparsingexample;

import android.content.Context;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.squareup.picasso.Picasso;

import java.util.ArrayList;

public class MyRecyclerViewAdapter extends RecyclerView.Adapter<MyRecyclerViewAdapter.MyRecyclerViewItemHolder> {
    private Context mContext;
    private ArrayList<Book> mArrayList;
    // Turkish lira symbol

    public MyRecyclerViewAdapter(Context mContext, ArrayList<Book> mArrayList) {
        this.mContext = mContext;
        this.mArrayList = mArrayList;
    }

    // Each object of the ViewHolder will be created here
    @NonNull
    @Override
    public MyRecyclerViewItemHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {

        LayoutInflater mLayoutInflater = LayoutInflater.from(parent.getContext());
        View itemView = (View) mLayoutInflater.inflate(R.layout.item_layout, parent, false);
        MyRecyclerViewItemHolder mViewHolder = new MyRecyclerViewItemHolder(itemView);

        return mViewHolder;
    }

    @Override
    public void onBindViewHolder(@NonNull MyRecyclerViewItemHolder holder, int position) {
        Book book = mArrayList.get(position);
        String imageNameAddress = book.getImgName();

        Picasso.get()
                .load(imageNameAddress)
                .into(holder.image);

        Log.d("IMAGE REQUESTED", imageNameAddress);

        holder.name.setText(book.getName());

    }
    // How many items exist in the list
    @Override
    public int getItemCount() {
        return mArrayList.size();
    }

    // This class is responsible for each item on the list
    public class MyRecyclerViewItemHolder extends RecyclerView.ViewHolder {
        ImageView image;
        TextView name;

        public MyRecyclerViewItemHolder(View itemView) {
            super(itemView);
            image = (ImageView) itemView.findViewById(R.id.imgBook);
            name = (TextView) itemView.findViewById(R.id.tvBookName);
        }
    }
}