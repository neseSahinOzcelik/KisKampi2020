package com.nese.week12_jsonparsingexample;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.app.ProgressDialog;
import android.os.AsyncTask;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.ProgressBar;
import android.widget.Toast;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.HashMap;

public class MainActivity extends AppCompatActivity {
    private RecyclerView mRecyclerView;
    private RecyclerView.LayoutManager mLayoutManager;
    private MyRecyclerViewAdapter mRecyclerAdapter;

    private RequestQueue mRequestQueue;

    private ProgressBar mProgressBar;
    int progressStatus = 0;

    // JSON related
    private JSONArray books;
    private JSONObject bookJSONObject;

    // ArrayList containing HashMap for RecyclerView
    private ArrayList<Book> mArrayList;

    public static final String TAG_BOOKS = "books";
    public static final String TAG_NAME = "name";
    public static final String TAG_AUTHOR = "author";
    public static final String TAG_YEAR = "year";
    public static final String TAG_IMG = "img";

    private static final String BOOKS_URL = "http://www.ctis.bilkent.edu.tr/ctis487/jsonBook/books.php";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        mProgressBar = findViewById(R.id.progressBar);
        mProgressBar.setVisibility(View.INVISIBLE);
        mProgressBar.setMax(100);

        mRecyclerView = (RecyclerView) findViewById(R.id.recyclerViewBooks);
        mLayoutManager = new LinearLayoutManager(this);
        mRecyclerView.setLayoutManager(mLayoutManager);

        // volley related (https://developer.android.com/training/volley/requestqueue)
        mRequestQueue = Volley.newRequestQueue(this);
    }

    public void onClick(View v) {

        mArrayList = new ArrayList<Book>();

        // Creating and showing the progress Dialog
        mProgressBar.setVisibility(View.VISIBLE);

        // volley related (https://developer.android.com/training/volley/request)
        JsonObjectRequest mJsonObjectRequest = new JsonObjectRequest (
                Request.Method.GET, BOOKS_URL, null,
                new Response.Listener<JSONObject>() {
                    @Override
                    public void onResponse(JSONObject response) {
                        bookJSONObject = response;

                        // Call to AsyncTask
                        new getBooks().execute();
                    }
                }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                Log.d("Result",
                        "ERROR JSONObject request" + error.toString());
                mProgressBar.setVisibility(View.INVISIBLE);
            }
        });

        // add request to queue
        mRequestQueue.add(mJsonObjectRequest);


    }

    private class getBooks extends AsyncTask<Void, Integer, Void> {

        // Main job should be done here
        @Override
        protected Void doInBackground(Void... params) {
            try {
                // Getting JSON Array
                books = bookJSONObject.getJSONArray(TAG_BOOKS);

                int incrementProgress = 100/books.length();

                // looping through all books
                for (int i = 0; i < books.length(); i++) {

                    progressStatus +=incrementProgress;

                    publishProgress(progressStatus);


                    JSONObject jsonObj = books.getJSONObject(i);

                    Thread.sleep(1000);

                    String name = jsonObj.getString(TAG_NAME);
                    String author = jsonObj.getString(TAG_AUTHOR);
                    String year = jsonObj.getString(TAG_YEAR);
                    String imgName = "http://www.ctis.bilkent.edu.tr/ctis487/jsonBook/"+jsonObj.getString(TAG_IMG);

                    if(jsonObj.has("publisher"))
                        Log.d("KEY PUBLISHER", "EXIST");
                    else
                        Log.d("KEY PUBLISHER", "NOT EXIST");

                    Book b = new Book(name, author, year, imgName);

                    mArrayList.add(b);
                }
            }
            catch (JSONException ee) {
                ee.printStackTrace();
            } catch (InterruptedException e) {
                e.printStackTrace();
            }

            return null;
        }

        @Override
        protected void onProgressUpdate(Integer... values) {
            super.onProgressUpdate(values);
            mProgressBar.setProgress(values[0]);
        }

        @Override
        protected void onPreExecute() {
            super.onPreExecute();
        }

        // What do you want to do after doInBackground() finishes
        @Override
        protected void onPostExecute(Void aVoid) {
            super.onPostExecute(aVoid);
            mProgressBar.setVisibility(View.INVISIBLE);

            if (mArrayList != null) {
                mRecyclerAdapter = new MyRecyclerViewAdapter(MainActivity.this, mArrayList);
                mRecyclerView.setAdapter(mRecyclerAdapter);
            }
            else
                Toast.makeText(MainActivity.this, "Not Found", Toast.LENGTH_LONG).show();
        }
    }
}
