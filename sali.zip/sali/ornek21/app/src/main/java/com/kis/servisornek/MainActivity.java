package com.kis.servisornek;

import androidx.appcompat.app.AppCompatActivity;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {
    EditText etSayi1, etSayi2;
    TextView tvSonuc;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        etSayi1 = findViewById(R.id.etSayi1);
        etSayi2 = findViewById(R.id.etSayi2);
        tvSonuc = findViewById(R.id.tvSonuc);

        IntentFilter intentFilter = new IntentFilter();
        intentFilter.addAction("TOPLAMA_ACTION");
        registerReceiver(mIntentReceiver, intentFilter);
    }

    public void onClick(View view) {
        Intent intent = new Intent(this, MyIntentService.class);
        Bundle b = new Bundle();
        b.putString("sayi1", etSayi1.getText().toString());
        b.putString("sayi2", etSayi2.getText().toString());
        intent.putExtras(b);
        startService(intent);
    }
    private BroadcastReceiver mIntentReceiver = new BroadcastReceiver() {
        @Override
        public void onReceive(Context context, Intent intent) {
            Bundle sonuc = intent.getExtras();
            String msg = sonuc.getString("sonuc");
            tvSonuc.setText(msg);

        }
    };
}
