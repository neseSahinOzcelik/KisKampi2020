package com.kis.servisornek;

import android.app.IntentService;
import android.content.Intent;
import android.os.Bundle;

public class MyIntentService extends IntentService {

    public MyIntentService() {
        super("MyIntentService");
    }

    @Override
    protected void onHandleIntent(Intent intent) {
        Bundle b = intent.getExtras();
        int s1 = Integer.parseInt(b.getString("sayi1"));
        int s2 = Integer.parseInt(b.getString("sayi2"));
        int topla = s1 + s2;

        try {
            Thread.sleep(1000);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }

        Intent intentSonuc = new Intent();
        Bundle bsonuc = new Bundle();
        bsonuc.putString("sonuc", s1+" + "+s2 +" = "+topla);
        intentSonuc.putExtras(bsonuc);

        intentSonuc.setAction("TOPLAMA_ACTION");
        getBaseContext().sendBroadcast(intentSonuc);
    }
}
