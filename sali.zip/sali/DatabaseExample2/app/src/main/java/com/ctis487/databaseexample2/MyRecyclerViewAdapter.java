package com.ctis487.databaseexample2;

import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;
import java.util.List;

public class MyRecyclerViewAdapter extends RecyclerView.Adapter<MyRecyclerViewAdapter.MyViewHolder> {

    Context context;
    ArrayList<Contact> data;

    public MyRecyclerViewAdapter(Context context, List<Contact> data) {
        this.context = context;
        this.data =(ArrayList<Contact>) data;
    }

    @Override
    public MyViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View v = LayoutInflater.from(context).inflate(R.layout.recyclerview_layout, parent, false);
        return new MyViewHolder(v);
    }

    @Override
    public void onBindViewHolder(MyViewHolder holder, int position) {
        //BIND DATA
        final Contact contact = data.get(position);
        holder.tvName.setText(contact.getName());

        holder.btnDetail.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String msg = contact.getId()+contact.getName()+"\n"+contact.getEmail();
                makeAndShowDialogBox(msg);
            }
        });

    }

    @Override
    public int getItemCount() {
        return data.size();
    }

    class MyViewHolder extends RecyclerView.ViewHolder{

        ImageButton btnDetail;
        TextView tvName;
        ImageView icon;

        MyViewHolder(View viewItem){
            super(viewItem);
            tvName = viewItem.findViewById(R.id.tvName);
            icon = viewItem.findViewById(R.id.imgIcon);
            btnDetail = viewItem.findViewById(R.id.btnDetail);
        }
    }

    private void makeAndShowDialogBox(String message) {
        AlertDialog.Builder mDialogBox = new AlertDialog.Builder(context);
        // set message, title, and icon
        mDialogBox.setTitle("Contact Detail");
        mDialogBox.setMessage(message);
        //mDialogBox.setIcon();

        // Set three option buttons
        mDialogBox.setPositiveButton("Ok",
                new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int whichButton) {
                        // whatever should be done when answering "YES" goes
                        // here
                    }
                });
        mDialogBox.create();
        mDialogBox.show();
    }

}
