package com.ctis487.databaseexample2;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;

import java.util.List;

public class SecondActivity extends AppCompatActivity {

    RecyclerView recylerContact;

    SQLiteDatabase db;
    List<Contact> data;
    DatabaseHelper dbHelper;
    EditText etKey;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_second);

        dbHelper = new DatabaseHelper(this);

        etKey = findViewById(R.id.etKey);
        data = ContactDB.getAllContact(dbHelper);

        recylerContact = findViewById(R.id.recylerContact);

        LinearLayoutManager layoutManaget = new LinearLayoutManager(this);
        recylerContact.setLayoutManager(layoutManaget);

        MyRecyclerViewAdapter adapter = new MyRecyclerViewAdapter(this, data);
        recylerContact.setAdapter(adapter);

    }
    public void onClick(View v){
        String key = etKey.getText().toString();
        data = ContactDB.findContact(dbHelper,key );
        MyRecyclerViewAdapter adapter = new MyRecyclerViewAdapter(this, data);
        recylerContact.setAdapter(adapter);

    }
}
