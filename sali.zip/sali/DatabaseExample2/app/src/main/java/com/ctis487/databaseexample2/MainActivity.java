package com.ctis487.databaseexample2;


import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.content.Intent;
import android.util.Log;
import android.widget.Button;
import android.widget.TextView;


public class MainActivity extends AppCompatActivity {

    DatabaseHelper dbHelper;

    EditText etId,etName, etEmail;
    TextView tvResult;
    Button btnFind;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        btnFind = findViewById(R.id.btnFind);

        dbHelper = new DatabaseHelper(this);

        Log.d("DATABASE", "OK");
        etId = findViewById(R.id.etId);
        etName = findViewById(R.id.etName);
        etEmail = findViewById(R.id.etEmail);
        tvResult = findViewById(R.id.tvResult);

        btnFind.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(MainActivity.this, SecondActivity.class);
                startActivity(intent);

            }
        });
    }

    public void onClick(View view) {
        boolean res=false;

        int id= Integer.parseInt(etId.getText().toString());
        String name = etName.getText().toString();
        String email = etEmail.getText().toString();

        if(view.getId() == R.id.btnAdd){
            long resinser = ContactDB.insertContact(dbHelper,id, name, email);
            if(resinser > 0){
                tvResult.setText("Contact "+name+" is added");
            }
        }
        else   if(view.getId() == R.id.btnUpdate){
            res =  ContactDB.updateContact(dbHelper,id, name, email);
            if(res)
                tvResult.setText("Update is done");
        }
        else {//Delete
            res = ContactDB.deleteContact(dbHelper, id);
            if(res)
                tvResult.setText("Delete is done");
        }

    }
}
